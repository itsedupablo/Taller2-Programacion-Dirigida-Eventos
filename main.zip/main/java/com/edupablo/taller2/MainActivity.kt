package com.edupablo.taller2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.loader.app.LoaderManager
import androidx.loader.content.Loader

class MainActivity : ComponentActivity() {

    private lateinit var configuracionLauncher: ActivityResultLauncher<Intent>
    private var backgroundColor by mutableStateOf(Color.White)
    private var savedName by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Obtener SharedPreferences
        val sharedPref = getSharedPreferences("app_preferences", Context.MODE_PRIVATE)

        // Iniciar el loader para cargar el nombre guardado en segundo plano
        LoaderManager.getInstance(this).initLoader(1, null, NameLoaderCallbacks(sharedPref))

        configuracionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val selectedColorInt = result.data?.getIntExtra("selectedColor", Color.White.toArgb())
                selectedColorInt?.let {
                    backgroundColor = Color(it)
                    saveColorInPreferences(backgroundColor)
                }
            }
        }

        setContent {
            MainActivityContent(
                backgroundColor = backgroundColor,
                savedName = savedName,
                onConfigureClick = {
                    val intent = Intent(this, ConfiguracionActivity::class.java)
                    configuracionLauncher.launch(intent)
                }
            )
        }
    }

    private inner class NameLoaderCallbacks(private val sharedPref: SharedPreferences) :
        LoaderManager.LoaderCallbacks<String> {

        override fun onCreateLoader(id: Int, args: Bundle?): Loader<String> {
            return NameLoader(this@MainActivity, sharedPref)
        }

        override fun onLoadFinished(loader: Loader<String>, data: String?) {
            if (data != null) {
                savedName = data
            }
        }

        override fun onLoaderReset(loader: Loader<String>) {
            // Puedes restablecer el nombre si lo necesitas
        }
    }

    private fun saveColorInPreferences(color: Color) {
        val sharedPref = getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putInt("background_color", color.toArgb())
            apply()
        }
    }
}

@Composable
fun MainActivityContent(
    backgroundColor: Color,
    savedName: String,
    onConfigureClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(backgroundColor),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (savedName.isEmpty()) {
            OutlinedTextField(
                value = savedName,
                onValueChange = { },
                label = { Text("Ingresa tu usuario") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = {
                // Lógica para guardar el nombre ingresado
            }) {
                Text("Guardar")
            }

            Spacer(modifier = Modifier.height(16.dp))
        } else {
            // Texto "Bienvenid@ usuario" con tamaño más grande y en negrita
            Text(
                text = "Bienvenid@: $savedName",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        Button(onClick = onConfigureClick) {
            Text("Configuración")
        }
    }
}
