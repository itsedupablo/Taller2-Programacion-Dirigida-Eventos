package com.edupablo.taller2

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.edupablo.taller2.ui.theme.Taller2Theme

class MainActivity : ComponentActivity() {
    private lateinit var configuracionLauncher: ActivityResultLauncher<Intent>
    private var backgroundColor by mutableStateOf(Color.White)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configuración del launcher para recibir el resultado de la ConfiguracionActivity
        configuracionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val selectedColorInt = result.data?.getIntExtra("selectedColor", Color.White.toArgb())
                selectedColorInt?.let {
                    backgroundColor = Color(it)
                    saveColorInPreferences(backgroundColor)
                }
            }
        }

        setContent {
            Taller2Theme {
                MainScreen(
                    backgroundColor = backgroundColor,
                    onSaveClick = { name ->
                        saveNameInPreferences(name)
                    },
                    onConfigClick = {
                        val intent = Intent(this, ConfiguracionActivity::class.java)
                        configuracionLauncher.launch(intent)
                    }
                )
            }
        }
    }

    // Función para guardar el nombre en SharedPreferences
    private fun saveNameInPreferences(name: String) {
        val sharedPref = getSharedPreferences("app_preferences", MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("saved_name", name)
            apply()
        }
    }

    // Función para guardar el color en SharedPreferences
    private fun saveColorInPreferences(color: Color) {
        val sharedPref = getSharedPreferences("app_preferences", MODE_PRIVATE)
        with(sharedPref.edit()) {
            putInt("background_color", color.toArgb())
            apply()
        }
    }
}

@Composable
fun MainScreen(
    backgroundColor: Color,
    onSaveClick: (String) -> Unit,
    onConfigClick: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var isNameSaved by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(backgroundColor),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (isNameSaved) {
            Text("Bienvenid@ $text", style = MaterialTheme.typography.headlineLarge)
        } else {
            // Caja de texto para que el usuario ingrese su nombre o usuario
            OutlinedTextField(
                value = text,
                onValueChange = { newText -> text = newText },
                label = { Text("Ingresa tu usuario") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Botón para guardar el nombre
            Button(
                onClick = {
                    onSaveClick(text)
                    isNameSaved = true
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botón para ir a la configuración
        Button(
            onClick = onConfigClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Configuración")
        }
    }

}
