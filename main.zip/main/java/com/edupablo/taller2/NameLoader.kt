package com.edupablo.taller2

import android.content.Context
import android.content.SharedPreferences
import androidx.loader.content.AsyncTaskLoader

class NameLoader(context: Context, private val sharedPref: SharedPreferences) : AsyncTaskLoader<String>(context) {
    override fun loadInBackground(): String {
        return sharedPref.getString("saved_name", "") ?: ""
    }
}