package com.edupablo.taller2

import android.content.Context
import android.content.SharedPreferences
import androidx.loader.content.AsyncTaskLoader
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

class ColorLoader(context: Context, private val sharedPref: SharedPreferences) : AsyncTaskLoader<Color>(context) {
    override fun loadInBackground(): Color {
        val colorInt = sharedPref.getInt("background_color", Color.White.toArgb())
        return Color(colorInt)
    }
}