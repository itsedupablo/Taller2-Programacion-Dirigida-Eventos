package com.edupablo.taller2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.loader.app.LoaderManager
import androidx.loader.content.Loader
import com.edupablo.taller2.ui.theme.Taller2Theme
import kotlinx.coroutines.launch
import java.util.Calendar

class PantallaInicio : ComponentActivity(), LoaderManager.LoaderCallbacks<Color> {
    private var backgroundColor by mutableStateOf(Color.White)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Iniciar el loader para cargar el color de fondo en segundo plano
        LoaderManager.getInstance(this).initLoader(0, null, this)

        setContent {
            Taller2Theme {
                PantallaInicioScreen(
                    backgroundColor = backgroundColor,
                    onNavigate = {
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                    }
                )
            }
        }
    }

    override fun onCreateLoader(id: Int, args: Bundle?): Loader<Color> {
        return ColorLoader(this, getSharedPreferences("app_preferences", Context.MODE_PRIVATE))
    }

    override fun onLoadFinished(loader: Loader<Color>, data: Color?) {
        if (data != null) {
            backgroundColor = data
        }
    }

    override fun onLoaderReset(loader: Loader<Color>) {
        // Manejar el reset si es necesario
    }
}

@Composable
fun PantallaInicioScreen(backgroundColor: Color, onNavigate: () -> Unit) {
    var greeting by remember { mutableStateOf("") }

    // Obtener el mensaje de saludo en segundo plano usando coroutines
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val message = getGreetingMessage()
            greeting = message
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(backgroundColor),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = greeting, style = MaterialTheme.typography.headlineLarge)

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onNavigate) {
            Text("Ir a la pantalla principal")
        }
    }
}

// Función suspendida para obtener el mensaje de saludo
suspend fun getGreetingMessage(): String {
    val calendar = Calendar.getInstance()
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 6..11 -> "Buenos días"
        in 12..20 -> "Buenas tardes"
        else -> "Buenas noches"
    }
}
