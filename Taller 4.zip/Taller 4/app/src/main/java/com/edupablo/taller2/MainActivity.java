package com.edupablo.taller2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    public static final int COLOR_REQUEST_CODE = 1;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float[] gravity = new float[3];
    private float[] linear_acceleration = new float[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configurar los fragmentos
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_user_container, new IngresarUsuarioFragment());
        fragmentTransaction.replace(R.id.fragment_list_container, new ListaFragment());
        fragmentTransaction.commit();

        // Inicializar el SensorManager y el acelerómetro
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Verifica si el dispositivo tiene acelerómetro
        if (accelerometer == null) {
            Toast.makeText(this, "Acelerómetro no disponible en este dispositivo", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Registrar el acelerómetro para que detecte cambios
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Detener el registro del acelerómetro cuando la actividad esté en pausa
        sensorManager.unregisterListener(this);
    }

    // Obtener el color seleccionado desde ConfigurationActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == COLOR_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                int color = data.getIntExtra("selected_color", Color.WHITE);
                findViewById(R.id.main_layout).setBackgroundColor(color);
                updateFragmentsBackgroundColor(color);
            }
        }
    }

    // Método para actualizar el color de fondo de los fragmentos
    public void updateFragmentsBackgroundColor(int color) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        for (Fragment fragment : fragmentManager.getFragments()) {
            if (fragment instanceof BackgroundUpdatable) {
                ((BackgroundUpdatable) fragment).updateBackgroundColor(color);
            }
        }
    }

    // Método que se llama cuando se detecta un cambio en los sensores
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // Filtrar el valor del acelerómetro para obtener solo la aceleración lineal
            final float alpha = 0.8f;

            // Se usa un filtro paso bajo para obtener solo la gravedad
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

            // Aceleración lineal
            linear_acceleration[0] = event.values[0] - gravity[0];
            linear_acceleration[1] = event.values[1] - gravity[1];
            linear_acceleration[2] = event.values[2] - gravity[2];

            // Detectar un movimiento significativo
            float magnitude = (float) Math.sqrt(linear_acceleration[0] * linear_acceleration[0]
                    + linear_acceleration[1] * linear_acceleration[1]
                    + linear_acceleration[2] * linear_acceleration[2]);

            // Si la magnitud del movimiento es mayor que un umbral, realizar una acción
            if (magnitude > 12) { // Umbral que puedes ajustar
                // Cambiar el color de fondo
                findViewById(R.id.main_layout).setBackgroundColor(Color.GREEN); // Por ejemplo, cambiar a verde
            } else {
                // Si el movimiento es pequeño, cambiar a blanco
                findViewById(R.id.main_layout).setBackgroundColor(Color.WHITE);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Este método no es necesario en este caso, pero lo debes sobrescribir
    }
}
