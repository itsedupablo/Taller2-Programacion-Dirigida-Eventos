package com.edupablo.taller2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class IngresarUsuarioFragment extends Fragment implements BackgroundUpdatable {
    private final ActivityResultLauncher<Intent> colorActivityResultLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    int selectedColor = result.getData().getIntExtra("selected_color", Color.WHITE);
                    ((MainActivity) requireActivity()).updateFragmentsBackgroundColor(selectedColor);
                }
            });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ingresar_usuario, container, false);

        // Referencia a las vistas
        EditText nameInput = view.findViewById(R.id.name_input);
        TextView welcomeText = view.findViewById(R.id.welcome_text);
        Button saveButton = view.findViewById(R.id.save_button);
        Button configButton = view.findViewById(R.id.config_button);

        // Configuración del botón Guardar
        saveButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString();
            if (!name.isEmpty()) {
                welcomeText.setText("Bienvenid@ " + name);
                welcomeText.setVisibility(View.VISIBLE);
                nameInput.setVisibility(View.GONE);
                saveButton.setVisibility(View.GONE);
            } else {
                nameInput.setError("Por favor, ingresa tu nombre");
            }
        });

        // Configuración del botón de Configuración
        configButton.setOnClickListener(v -> {
            Intent intent = new Intent(requireActivity(), ConfigurationActivity.class);
            colorActivityResultLauncher.launch(intent);
        });

        return view;
    }

    @Override
    public void updateBackgroundColor(int color) {
        // Cambiar el color de fondo solo si el view no es nulo
        if (getView() != null) {
            getView().setBackgroundColor(color);
        }
    }
}
