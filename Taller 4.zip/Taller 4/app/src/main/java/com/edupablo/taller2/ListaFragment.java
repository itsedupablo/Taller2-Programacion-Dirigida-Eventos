package com.edupablo.taller2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class ListaFragment extends Fragment implements BackgroundUpdatable {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflar el diseño del fragmento
        View view = inflater.inflate(R.layout.fragment_lista, container, false);

        // Configurar la lista
        ListView listView = view.findViewById(R.id.list_view);
        List<String> items = new ArrayList<>();
        items.add("Elemento 1");
        items.add("Elemento 2");
        items.add("Elemento 3");
        items.add("Elemento 4");
        items.add("Elemento 5");
        items.add("Elemento 6");
        items.add("Elemento 7");
        items.add("Elemento 8");


        // Configurar el adaptador para la lista
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_list_item_1,
                items
        );
        listView.setAdapter(adapter);

        return view;
    }

    @Override
    public void updateBackgroundColor(int color) {
        // Cambiar el color de fondo solo si el view no es nulo
        if (getView() != null) {
            getView().setBackgroundColor(color);
        }
    }
}
