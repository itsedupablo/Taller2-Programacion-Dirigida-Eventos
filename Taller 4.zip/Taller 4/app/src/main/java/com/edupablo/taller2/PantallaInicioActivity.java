package com.edupablo.taller2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

public class PantallaInicioActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_inicio);

        // Referencias a las vistas
        layout = findViewById(R.id.start_layout);
        TextView greetingText = findViewById(R.id.greeting_text);
        Button navigateButton = findViewById(R.id.navigate_button);

        // Cargar color de fondo
        sharedPreferences = getSharedPreferences("app_preferences", MODE_PRIVATE);
        int backgroundColor = sharedPreferences.getInt("background_color", Color.WHITE);
        layout.setBackgroundColor(backgroundColor);

        // Configurar saludo
        new Handler().postDelayed(() -> greetingText.setText(getGreetingMessage()), 500);

        // Configurar botón de navegación
        navigateButton.setOnClickListener(v -> {
            Intent intent = new Intent(PantallaInicioActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }

    private String getGreetingMessage() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour >= 6 && hour <= 11) {
            return "Buenos días";
        } else if (hour >= 13 && hour <= 20) {
            return "Buenas tardes";
        } else {
            return "Buenas noches";
        }
    }
}
