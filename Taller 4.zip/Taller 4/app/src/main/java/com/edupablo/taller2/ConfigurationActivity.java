package com.edupablo.taller2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ConfigurationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuration);

        // Botones de cambio de color
        Button colorButtonRed = findViewById(R.id.color_button_red);
        Button colorButtonBlue = findViewById(R.id.color_button_blue);
        Button colorButtonGreen = findViewById(R.id.color_button_green);

        // Configurar los botones para cambiar el color de fondo
        colorButtonRed.setOnClickListener(v -> changeColor(Color.RED));
        colorButtonBlue.setOnClickListener(v -> changeColor(Color.BLUE));
        colorButtonGreen.setOnClickListener(v -> changeColor(Color.GREEN));
    }

    private void changeColor(int color) {
        // Crear el Intent para devolver el color seleccionado a MainActivity
        Intent resultIntent = new Intent();
        resultIntent.putExtra("selected_color", color);
        setResult(RESULT_OK, resultIntent);
        finish();  // Volver a la MainActivity
    }
}
