package com.edupablo.taller2;

public interface BackgroundUpdatable {
    void updateBackgroundColor(int color);
}
